# LoveHouse Official CLT — Source Summary

**Source:** lovehouseofficialclt.com (Wix single-page site + shop)

## What it is
LoveHouse Official CLT is an underground house-music brand/collective based in
Charlotte, NC. It celebrates soulful and deep house culture — DJs, parties,
mixes, and merch — with the tagline **"House music rooted in the underground."**

## Brand mood
- Grungy, distressed, high-energy underground nightlife aesthetic.
- Iconic logo: bold white textured "LOVE HOUSE" type on a vivid red heart, black background.
- Imagery: DJs mid-mix under blue/purple/magenta club lighting, disco-ball dot spheres, dark crowds.
- Tone: bold, welcoming, party-forward, community-driven ("JOIN THE PARTY!").

## Structure / offerings (source nav)
- **Home** — hero, tagline, newsletter subscribe ("JOIN THE PARTY!"), Instagram follow.
- **Music** — mixes / releases / the LoveHouse sound (soulful + deep house).
- **Events** — parties and shows in Charlotte; "BOOK ME" DJ booking.
- **News & Culture** — blog / articles.
- **Online Store** — merch drops (e.g. "LoveHouse Summer 2026", all products).
- **Social** — Instagram @lovehouseofficialclt.

## Value proposition
A home for Charlotte's house-music community: real underground sound, live events,
mixes, and merch — built on love for the dance floor.

## Reimagined site plan (max 5 nav destinations)
Home · Music · Events · Blog (News & Culture) · Contact/Booking
