const { execSync } = require('node:child_process')
const fs = require('node:fs')
const path = require('node:path')

const MAX_DOWNLOAD_BYTES = 30 * 1024 * 1024
const MAX_WIDTH_PX = 1920
const WEBP_QUALITY = 80

const fail = message => {
  console.error(message)
  process.exit(1)
}

const resolveSharp = () => {
  try {
    return require('sharp')
  } catch (error) {
    const globalRoot = execSync('npm root -g').toString().trim()
    return require(path.join(globalRoot, 'sharp'))
  }
}

const main = async () => {
  const [imageUrl, destination] = process.argv.slice(2)

  if (!imageUrl || !destination) {
    fail('usage: node compressImage.cjs "<imageUrl>" "public/images/<name>.webp"')
  }
  if (!destination.startsWith('public/')) {
    fail('destination must be inside public/')
  }
  if (destination.includes('..')) {
    fail('destination must not contain ..')
  }

  const response = await fetch(imageUrl, {
    redirect: 'follow',
    headers: {
      'User-Agent':
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36',
      Accept: 'image/*',
    },
  })

  if (!response.ok) {
    fail('download failed: HTTP ' + response.status)
  }

  const imageBytes = Buffer.from(await response.arrayBuffer())

  if (imageBytes.byteLength > MAX_DOWNLOAD_BYTES) {
    fail('image too large: ' + imageBytes.byteLength + ' bytes')
  }

  fs.mkdirSync(path.dirname(destination), { recursive: true })

  const contentType = response.headers.get('content-type') || ''
  const isSvg = contentType.includes('svg') || destination.endsWith('.svg')

  if (isSvg) {
    fs.writeFileSync(destination, imageBytes)
  } else {
    const sharp = resolveSharp()
    await sharp(imageBytes)
      .rotate()
      .resize({ width: MAX_WIDTH_PX, withoutEnlargement: true })
      .webp({ quality: WEBP_QUALITY })
      .toFile(destination)
  }

  console.log(
    JSON.stringify({ destination, bytes: fs.statSync(destination).size }),
  )
}

main().catch(error => fail(error.message))
