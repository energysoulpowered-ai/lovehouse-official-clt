#!/usr/bin/env bash
# Stop hook: verify the site is healthy before the agent is allowed to finish.
#   1. `astro check` — full TypeScript / template type-checking.
#   2. `astro build` — compiles every page; catches render crashes (e.g. undefined
#      icon imports), broken imports, and bad routes.
# Exit 0  -> both passed, agent may stop.
# Exit 2  -> something failed; stderr is fed back to the agent so it fixes & re-checks.

cd "$CLAUDE_PROJECT_DIR" || exit 0

fail() {
  {
    echo "HEALTH CHECK FAILED ($1) — the site is NOT safe to run."
    echo "Fix the errors below, then it will be re-checked automatically."
    echo "Do not stop until both \`npm run check\` and \`npm run build\` pass."
    echo
    echo "----- $1 output -----"
    echo "$2"
  } >&2
  exit 2
}

out=$(npm run check 2>&1) || fail "npm run check" "$out"
out=$(npm run build 2>&1) || fail "npm run build" "$out"

exit 0
